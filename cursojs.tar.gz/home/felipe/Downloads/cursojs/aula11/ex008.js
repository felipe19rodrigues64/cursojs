var vel = 50.5
console.log(`A velocidade é ${vel}.`)
if (vel > 60){ // Condição simples
    console.log("Você ultrapassou a velocidade permitida. MULTADO!")
}
console.log("Dirija sempre usando cinto de segurança!")
