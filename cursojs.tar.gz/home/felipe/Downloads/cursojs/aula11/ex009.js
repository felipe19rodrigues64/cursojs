var pais = 'BRASIL'

console.log(`Vivendo em ${pais}`)
if (pais=='BRASIL'){
    console.log("Você é brasileiro!")
} else {
    console.log("Você é estrangeiro!")
}
