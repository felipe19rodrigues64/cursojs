
console.log('Vai começar')

for (var c = 1; c <= 4; c++) {
    console.log(c)

}
console.log('FIM')
