
var c = 1
console.log("while")
while(c <= 6){
    console.log(`passo ${c}`)
    c++
}

var c = 1
console.log("do")
do {
    console.log(`passo ${c}`)
    c++
} while(c <= 3)

/* 
console.log("Tudo bem!")
console.log("Tudo bem!")
console.log("Tudo bem!")
console.log("Tudo bem!")
console.log("Tudo bem!")
console.log("Tudo bem!")
 */