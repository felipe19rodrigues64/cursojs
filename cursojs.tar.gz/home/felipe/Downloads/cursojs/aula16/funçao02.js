function soma(numero1 = 0, numero2 = 0) {
    return numero1 + numero2
}

console.log(soma(7,5))

