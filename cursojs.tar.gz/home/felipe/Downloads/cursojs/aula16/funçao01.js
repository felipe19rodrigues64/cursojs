function parimpar(numero){
    if (numero % 2 == 0 ){
        return 'par'
    } else {
        return 'impar'
    }
}

console.log(parimpar(11))

/*
    let res = parimpar(11)
    console.log(res)
 */
